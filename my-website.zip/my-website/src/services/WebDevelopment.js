import React from "react";

function WebDevelopment() {
  return (
    <div>
      <h3>Web Development</h3>
      <p>We provide full-stack web development services.</p>
    </div>
  );
}

export default WebDevelopment;
