import React from "react";

function MobileDevelopment() {
  return (
    <div>
      <h3>Mobile Development</h3>
      <p>We provide full-stack web development services.</p>
    </div>
  );
}

export default MobileDevelopment;
