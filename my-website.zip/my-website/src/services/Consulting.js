import React from "react";

const Consulting = () => {
  return (
    <div>
      <h3>Consulting Development</h3>
      <p>We provide full-stack Consulting development services.</p>
    </div>
  );
};

export default Consulting;
