import React from "react";

function ContactPage() {
  return (
    <div>
      <h2>Contact</h2>
      <p>Answers to frequently asked questions.</p>
    </div>
  );
}

export default ContactPage;
