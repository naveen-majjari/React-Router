import React from "react";

function FAQPage() {
  return (
    <div>
      <h2>FAQ</h2>
      <p>Answers to frequently asked questions.</p>
    </div>
  );
}

export default FAQPage;
