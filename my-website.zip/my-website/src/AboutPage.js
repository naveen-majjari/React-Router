import React from "react";
function AboutPage() {
  return (
    <div>
      <h2> About </h2>
      <p>
        {" "}
        This website provides a platform for sharing and analyzing agricultural
        data collected from IoT sensors .{" "}
      </p>
    </div>
  );
}
export default AboutPage;
