function HomePage() {
  return (
    <div>
      <h1> Welcome to the IoT Data Repository </h1>
      <p>
        {" "}
        This platform provides a secure way to store and share agricultural data
        .{" "}
      </p>
    </div>
  );
}
export default HomePage;
